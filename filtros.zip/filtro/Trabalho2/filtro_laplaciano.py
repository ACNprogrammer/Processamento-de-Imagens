# Aplica o filtro laplaciano

from PIL import Image

# Converte a imagem para uma matriz
def imagem_para_matriz(imagem):
    largura, altura = imagem.size
    matriz = []
    for y in range(altura):
        linha = []
        for x in range(largura):
            pixel = imagem.getpixel((x, y))
            linha.append(pixel)
        matriz.append(linha)
    return matriz

# Converte a matriz para uma imagem
def matriz_para_imagem(matriz):
    altura = len(matriz)
    largura = len(matriz[0])
    imagem = Image.new("RGB", (largura, altura))
    for y in range(altura):
        for x in range(largura):
            imagem.putpixel((x, y), tuple(matriz[y][x]))
    return imagem

def filtro_laplaciano(matriz):
    altura = len(matriz)
    largura = len(matriz[0])
    nova_matriz = [[(0, 0, 0) for _ in range(largura)] for _ in range(altura)]

    # 4 Máscaras laplacianas
    
    mascara = [[ 0, -1,  0],
               [-1,  4, -1],
               [ 0, -1,  0]]

    #mascara = [[ 0,  1,  0],
             #  [ 1, -4,  1],
             #  [ 0,  1,  0]]
               
    #mascara = [[ 1,  1,  1],
               #[ 1, -8,  1],
               #[ 1,  1,  1]]
               
    #mascara = [[-1, -1, -1],
              # [-1,  8, -1],
              # [-1, -1, -1]]
              
    # Percorre cada pixel da imagem 
    for y in range(1, altura - 1):
        for x in range(1, largura - 1):
            soma_r = soma_g = soma_b = 0
            
            # Aplica a máscara laplaciana 3x3
            for i in range(-1, 2):
                for j in range(-1, 2):
                    pixel = matriz[y + i][x + j]
                    coef = mascara[i + 1][j + 1]
                    
                    soma_r += pixel[0] * coef
                    soma_g += pixel[1] * coef
                    soma_b += pixel[2] * coef

            # Limita os valores entre 0 e 255 para garantir valores válidos de cor
            nova_r = max(0, min(255, soma_r))
            nova_g = max(0, min(255, soma_g))
            nova_b = max(0, min(255, soma_b))
            
            # Atualiza a nova matriz
            nova_matriz[y][x] = (nova_r, nova_g, nova_b)
    
    return nova_matriz

imagem_original = Image.open('imagem.jpg')

matriz_imagem = imagem_para_matriz(imagem_original)

# Aplica o filtro laplaciano
matriz_laplaciana = filtro_laplaciano(matriz_imagem)

imagem_laplaciana = matriz_para_imagem(matriz_laplaciana)

imagem_laplaciana.save('imagem_laplaciana.jpg')

print("Imagem laplaciana salva como 'imagem_laplaciana.jpg'")
