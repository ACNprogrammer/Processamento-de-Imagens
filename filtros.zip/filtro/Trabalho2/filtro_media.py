from PIL import Image

# Converte a imagem para uma matriz
def imagem_para_matriz(imagem):
    largura, altura = imagem.size
    matriz = []
    for y in range(altura):
        linha = []
        for x in range(largura):
            pixel = imagem.getpixel((x, y))
            linha.append(pixel)
        matriz.append(linha)
    return matriz

# Converte a matriz para uma imagem
def matriz_para_imagem(matriz):
    altura = len(matriz)
    largura = len(matriz[0])
    imagem = Image.new("RGB", (largura, altura))
    for y in range(altura):
        for x in range(largura):
            imagem.putpixel((x, y), tuple(matriz[y][x]))
    return imagem

# Filtro da média
def filtro_media(matriz, tamanho_kernel=3):
    altura = len(matriz)
    largura = len(matriz[0])
    offset = tamanho_kernel // 2
    nova_matriz = [[(0, 0, 0) for _ in range(largura)] for _ in range(altura)]

    # Percorre cada pixel da imagem
    for y in range(offset, altura - offset):  
        for x in range(offset, largura - offset):
            soma_r = soma_g = soma_b = 0
            contador = 0
            
            for i in range(-offset, offset + 1):
                for j in range(-offset, offset + 1):
                    pixel = matriz[y + i][x + j]
                    soma_r += pixel[0]
                    soma_g += pixel[1]
                    soma_b += pixel[2]
                    contador += 1
            
            # Calcula a média
            media_r = soma_r // contador
            media_g = soma_g // contador
            media_b = soma_b // contador
            
            # Atualiza a nova matriz
            nova_matriz[y][x] = (media_r, media_g, media_b)
    
    return nova_matriz

imagem_original = Image.open('imagem2.jpg')

matriz_imagem = imagem_para_matriz(imagem_original)

# Aplica o filtro da média 
matriz_suavizada = filtro_media(matriz_imagem, tamanho_kernel=3)

imagem_suavizada = matriz_para_imagem(matriz_suavizada)

imagem_suavizada.save('imagem_suavizada.jpg')

print("Imagem suavizada com filtro da média, salva como 'imagem_suavizada.jpg'")
