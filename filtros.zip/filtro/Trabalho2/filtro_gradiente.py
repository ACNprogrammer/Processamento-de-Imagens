import math
from PIL import Image

def imagem_para_matriz(imagem):
    largura, altura = imagem.size
    matriz = []
    for y in range(altura):
        linha = []
        for x in range(largura):
            pixel = imagem.getpixel((x, y))
            linha.append(pixel)
        matriz.append(linha)
    return matriz

# Converte a matriz para uma imagem
def matriz_para_imagem(matriz):
    altura = len(matriz)
    largura = len(matriz[0])
    imagem = Image.new("RGB", (largura, altura))
    for y in range(altura):
        for x in range(largura):
            imagem.putpixel((x, y), tuple(matriz[y][x]))
    return imagem
    
# Aplica o filtro gradiente (Sobel)

def filtro_gradiente(matriz):
    altura = len(matriz)
    largura = len(matriz[0])
    nova_matriz = [[(0, 0, 0) for _ in range(largura)] for _ in range(altura)]

    # Máscaras de Sobel para gradiente horizontal e vertical
    
    Gx = [[-1, 0, 1],
          [-2, 0, 2],
          [-1, 0, 1]]
    
    Gy = [[-1, -2, -1],
          [ 0,  0,  0],
          [ 1,  2,  1]]

    # Percorre cada pixel da imagem (exceto bordas)
    for y in range(1, altura - 1):
        for x in range(1, largura - 1):
            soma_gx_r = soma_gx_g = soma_gx_b = 0
            soma_gy_r = soma_gy_g = soma_gy_b = 0

            # Aplica as máscaras Sobel (Gx e Gy) para cada vizinhança 3x3
            for i in range(-1, 2):
                for j in range(-1, 2):
                    pixel = matriz[y + i][x + j]

                    # Gradiente horizontal (Gx)
                    coef_gx = Gx[i + 1][j + 1]
                    soma_gx_r += pixel[0] * coef_gx
                    soma_gx_g += pixel[1] * coef_gx
                    soma_gx_b += pixel[2] * coef_gx

                    # Gradiente vertical (Gy)
                    coef_gy = Gy[i + 1][j + 1]
                    soma_gy_r += pixel[0] * coef_gy
                    soma_gy_g += pixel[1] * coef_gy
                    soma_gy_b += pixel[2] * coef_gy

            # Calcula o gradiente final para cada canal de cor (R, G, B)
            grad_r = min(255, abs(soma_gx_r) + abs(soma_gy_r))
            grad_g = min(255, abs(soma_gx_g) + abs(soma_gy_g))
            grad_b = min(255, abs(soma_gx_b) + abs(soma_gy_b))

            # Atualiza a nova matriz
            nova_matriz[y][x] = (grad_r, grad_g, grad_b)

    return nova_matriz


imagem_original = Image.open('imagem.jpg')

matriz_imagem = imagem_para_matriz(imagem_original)

# Aplica o filtro gradiente
matriz_gradiente = filtro_gradiente(matriz_imagem)

imagem_gradiente = matriz_para_imagem(matriz_gradiente)

imagem_gradiente.save('imagem_gradiente.jpg')

print("Imagem gradiente salva como 'imagem_gradiente.jpg'")
